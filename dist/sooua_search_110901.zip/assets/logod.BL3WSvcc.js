const o="/assets/logod-CLmR-o37.png";export{o as _};
