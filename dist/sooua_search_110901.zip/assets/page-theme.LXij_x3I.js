import{u as t}from"./index-Cmaqy1Jl.js";function r(){try{return"light"===t("sooua_theme")}catch(r){return!1}}function n(t){}export{n as a,r as i};
