const s="/assets/sooua1024-BgW6PB_G.png";export{s as _};
