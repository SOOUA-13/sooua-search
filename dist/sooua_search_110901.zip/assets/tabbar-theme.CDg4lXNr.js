import{u as t}from"./index-Cmaqy1Jl.js";function o(o="light"===t("sooua_theme")){try{document.documentElement.classList.toggle("sooua-tab-light",!!o)}catch(e){}}export{o as a};
