const s="/assets/wx-mp-qr-CCjgSlM-.png";export{s as _};
